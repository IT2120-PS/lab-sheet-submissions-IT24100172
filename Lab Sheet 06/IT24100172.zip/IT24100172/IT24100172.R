setwd("C:/Users/thanu/Desktop/IT24100172")
getwd()

## Question 01
# (i) Binomial Distribution -> X ~ Binomial(n = 50, p = 0.85)

# (ii) Probability at least 47 passed
pbinom(46, 50, 0.85, lower.tail = FALSE)

## Question 02
# (i) X = Number of customer calls received by a call center per hour

# (ii) Poisson Distribution -> X ~ Poisson(lambda = 12)

# (iii) Probability of exactly 5 calls in an hour
dpois(15,12)

