setwd("C:\\Users\\it24100172\\Desktop\\it24100172")

##part 1
branch_data <- read.table("Exercise.txt", header = TRUE,sep=",")
#check first few rows
head(branch_data)

#part 2
# check structure of the data
str(branch_data)

#check summary statistics
summary (branch_data)

#part 3
boxplot(branch_data$Sales_X1,
         main="Boxplot of sales",
         ylab="Sales",col="lightblue")

#part 4
#five number summary
fivenum(branch_data$Advertising_X2)
#calculate iqr
IQR(branch_data$Advertising_X2)

#part 5
find_outliners <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <-IQR(x)
  
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

find_outliners(branch_data$Years_x3)

