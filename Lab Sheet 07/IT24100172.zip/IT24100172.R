setwd("C:/Users/thanu/Desktop/IT24100172")
getwd()

## Question 01
# Probability of train arrive between 8:10 a.m. and 8:25 a.m.
punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

## Question 02
#  Probability that update will take at most 2 hours
pexp(2, rate = 1/3, lower.tail = TRUE)

## Question 03
# (i) probability that a randomly selected person has an IQ above 130
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

# (ii) probability that a randomly selected person has an IQ above 130
qnorm(0.95, mean=100,sd=15)

